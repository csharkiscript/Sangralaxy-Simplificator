def echo(text):
    print(text)

def say(text):
    print(text)

def text(text):
    print(text)

def e(text):
    print(text)

def s(text):
    print(text)

def t(text):
    print(text)

def p(text):
    print(text)

def ds(I):
    n = type(I)

    if n == str:
        print('Type:', type(I))
        print('Is space:', I.isspace())
        print('Is alpha:', I.isalpha())
        print('Is upper:', I.isupper())
        print('Is lower:', I.islower())
        print('Is title:', I.istitle())

    if n == int:
        print('Type:', type(I))
   
    if n == float:
        print('Type:', type(I))
        Ifo = int(n)
        print(Ifo)
            
def f(text1, text2, text3, text4, text5):
    print(text1)
    if text2 != 'O':
        print(text2)
    if text3 != 'O':
        print(text3)
    if text4 != 'O':
        print(text4)
    if text5 != 'O':
        print(text5)





    



    
